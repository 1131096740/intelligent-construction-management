'use strict';

const capacitySnapshotSql = `
DO $onboarding_capacity_observation$
DECLARE observed jsonb;
BEGIN
  BEGIN
    WITH clients AS (
  SELECT datname, usename, state FROM pg_catalog.pg_stat_activity
  WHERE backend_type='client backend' AND pid<>pg_backend_pid()
)
SELECT jsonb_build_object(
 'max',current_setting('max_connections')::int,
 'superuserReserved',current_setting('superuser_reserved_connections')::int,
 'roleReserved',current_setting('reserved_connections')::int,
 'runtimeLimit',(SELECT rolconnlimit FROM pg_catalog.pg_roles WHERE rolname='onboarding_runtime'),
 'databaseLimit',(SELECT datconnlimit FROM pg_catalog.pg_database WHERE datname=current_database()),
 'otherClients',(SELECT count(*) FROM clients),
 'sameDatabase',(SELECT count(*) FROM clients WHERE datname=current_database()),
 'runtime',(SELECT count(*) FROM clients WHERE usename='onboarding_runtime'),
 'runtimeActive',(SELECT count(*) FROM clients WHERE usename='onboarding_runtime' AND state='active'),
 'runtimeIdleInTransaction',(SELECT count(*) FROM clients WHERE usename='onboarding_runtime' AND state LIKE 'idle in transaction%')
) INTO observed;
    PERFORM pg_catalog.set_config('jg.onboarding_connection_observation',observed::text,true);
  EXCEPTION WHEN OTHERS OR query_canceled THEN
    NULL;
  END;
END
$onboarding_capacity_observation$;
SELECT pg_catalog.current_setting('jg.onboarding_connection_observation',true);`;

function readCapacitySnapshot(stdout) {
  try {
    const parsed=JSON.parse(stdout.trim());
    const keys=['max','superuserReserved','roleReserved','runtimeLimit','databaseLimit',
      'otherClients','sameDatabase','runtime','runtimeActive','runtimeIdleInTransaction'];
    if (!parsed || !keys.every(key=>Number.isSafeInteger(parsed[key])&&parsed[key]>=
      (key==='runtimeLimit'||key==='databaseLimit'?-1:0))) return null;
    return Object.fromEntries(keys.map(key=>[key,parsed[key]]));
  } catch {
    return null;
  }
}

const patterns = [
  ['GLOBAL', /^sorry, too many clients already$/u],
  ['SUPERUSER_RESERVE', /^remaining connection slots are reserved for (?:non-replication superuser connections|roles with the SUPERUSER attribute)$/u],
  ['ROLE_RESERVE', /^remaining connection slots are reserved for roles with privileges of the "pg_use_reserved_connections" role$/u],
  ['ROLE_LIMIT', /^too many connections for role "[^"]+"$/u],
  ['DATABASE_LIMIT', /^too many connections for database "[^"]+"$/u],
];

function readCapacityLog(text) {
  const counts = {};
  let first = null;
  for (const line of text.split('\n')) {
    const match=/^NATIVE_TASK16 \[\d+\] FATAL:\s+(?:(\d{5}):\s+)?(.*)$/u.exec(line);
    if (!match || (match[1] && match[1]!=='53300')) continue;
    const [,sqlstate,message]=match;
    const category=patterns.find(([,pattern])=>pattern.test(message))?.[0] ?? (sqlstate==='53300'?'UNCLASSIFIED_CAPACITY':null);
    if (!category) continue;
    first??=category;
    counts[category]=(counts[category]??0)+1;
  }
  return { first, counts };
}

function observeWithOwnerSql(original) {
  return `BEGIN;
${capacitySnapshotSql}
${original}
COMMIT;`;
}

async function revokeAndVerify(revoke, verify) {
  let observation;
  try {
    observation = await revoke();
  } catch (error) {
    await verify().catch(() => undefined);
    throw error;
  }
  await verify();
  return observation;
}

module.exports = { capacitySnapshotSql, readCapacitySnapshot, readCapacityLog, observeWithOwnerSql, revokeAndVerify };

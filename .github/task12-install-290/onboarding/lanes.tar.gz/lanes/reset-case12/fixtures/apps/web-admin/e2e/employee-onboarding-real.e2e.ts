import { expect, test } from "@playwright/test";
import { expectNoDocumentHorizontalOverflow } from "./helpers/responsive-assertions";

// Task04 reset UI expectations are PREPARED / NOT RUN in this source-only change.
test("真实注册、董事长批准、本人登录与管理员重置密码", async ({ page, browser }, testInfo) => {
  const phone = testInfo.project.name === "mobile" ? "13911000002" : "13911000001";
  const name = `验收员工${testInfo.project.name === "mobile" ? "手机" : "电脑"}`;
  const password = "Local-Onboarding-01";
  await page.goto("/register");
  await page.getByPlaceholder("请输入本人真实姓名").fill(name);
  await page.getByPlaceholder("请输入本人手机号").fill(phone);
  await page.getByPlaceholder("请设置至少8位密码").fill(password);
  await page.getByPlaceholder("请再输入一次密码").fill(password);
  await page.getByRole("button", { name: "提交入职申请" }).click();
  await expect(page.getByText("等待综合部或董事长审核", { exact: true })).toBeVisible();
  await expectNoDocumentHorizontalOverflow(page);

  const managerContext = await browser.newContext({ ...testInfo.project.use });
  try {
    const manager = await managerContext.newPage();
    await manager.goto("http://127.0.0.1:5199/login");
    await manager.getByPlaceholder("请输入手机号").fill(process.env.ONBOARDING_MANAGER_PHONE!);
    await manager.getByPlaceholder("请输入密码").fill(password);
    await manager.getByRole("button", { name: "登录", exact: true }).click();
    await expect(manager).not.toHaveURL(/login/);
    const approvalResponses: Array<{ route: "directory" | "capabilities" | "applications"; status: number }> = [];
    manager.on("response", (response) => {
      if (approvalResponses.length >= 12 || response.request().method() !== "GET") return;
      const url = new URL(response.url());
      if (url.origin !== "http://127.0.0.1:5199") return;
      const route = url.pathname === "/api/organization/directory" ? "directory"
        : url.pathname === "/api/organization/management-capabilities" ? "capabilities"
        : url.pathname === "/api/employee-onboarding/applications" ? "applications" : undefined;
      if (route) approvalResponses.push({ route, status: response.status() });
    });
    await manager.goto("http://127.0.0.1:5199/组织权限");
    const row = manager.locator("tr, article.employee-card, article.application-card, article.roster-card").filter({ hasText: phone });
    try {
      await row.getByRole("button", { name: "审核申请", exact: true }).click();
    } catch (error) {
      const controls = await row.getByRole("button", { name: "审核申请", exact: true })
        .evaluateAll((buttons) => buttons.slice(0, 4).map((button) => ({
          visible: button.getClientRects().length > 0 && getComputedStyle(button).visibility !== "hidden",
          enabled: !button.matches(":disabled") && button.getAttribute("aria-disabled") !== "true",
        }))).catch(() => null);
      const rows = await row.count().then((count) => Math.min(count, 5)).catch(() => null);
      console.log("ONBOARDING_RESET_OBS " + JSON.stringify({
        project: testInfo.project.name === "mobile" ? "mobile" : "desktop",
        action: "APPROVAL_CLICK", rows, controls, responses: approvalResponses,
      }));
      throw error;
    }
    const drawer = manager.locator(".t-drawer__content-wrapper");
    await drawer.locator('[data-field="departmentId"]').click();
    const departmentOption = manager.locator(".t-select__dropdown:visible .t-select-option").filter({ hasText: "入职浏览器验收部门" });
    await expect(departmentOption).toHaveCount(1);
    await departmentOption.click();
    await drawer.locator('[data-field="initialRoleKey"]').click();
    const financeOption = manager.locator(".t-select__dropdown:visible .t-select-option").filter({ hasText: "财务经办" });
    await expect(financeOption).toHaveCount(1);
    await financeOption.click();
    await drawer.locator('[data-field="initialRoleScope"]').click();
    const scopeOption = manager.locator(".t-select__dropdown:visible .t-select-option").filter({ hasText: "公司岗位（适用全部项目）" });
    await expect(scopeOption).toHaveCount(1);
    await scopeOption.click();
    await drawer.getByText("我已核对员工本人及手机号", { exact: true }).click();
    await drawer.getByPlaceholder("请输入本人当前登录密码").fill(password);
    const resetResponses: Array<{ route: "review" | "directory" | "capabilities"; status: number }> = [];
    manager.on("response", (response) => {
      if (resetResponses.length >= 12) return;
      const url = new URL(response.url());
      if (url.origin !== "http://127.0.0.1:5199") return;
      const method = response.request().method();
      const route =
        method === "POST" && /^\/api\/employee-onboarding\/applications\/[^/]+\/review$/u.test(url.pathname)
          ? "review"
          : method === "GET" && url.pathname === "/api/organization/directory"
            ? "directory"
            : method === "GET" && url.pathname === "/api/organization/management-capabilities"
              ? "capabilities" : undefined;
      if (route) resetResponses.push({ route, status: response.status() });
    });
    const reviewRequest = manager.waitForRequest((request) => request.method() === "POST"
      && /\/api\/employee-onboarding\/applications\/[^/]+\/review$/.test(new URL(request.url()).pathname));
    await drawer.getByRole("button", { name: "批准开通", exact: true }).click();
    expect((await reviewRequest).postDataJSON().roles).toEqual([{ roleKey: "finance_staff", scope: "global" }]);
    await expect(drawer).toHaveCount(0);
    await page.getByRole("button", { name: "刷新审核结果" }).click();
    await expect(page.getByText("审核通过，账号已开通", { exact: true })).toBeVisible();
    await page.getByRole("link", { name: "返回登录" }).click();
    await page.getByPlaceholder("请输入手机号").fill(phone);
    await page.getByPlaceholder("请输入密码").fill(password);
    await page.getByRole("button", { name: "登录", exact: true }).click();
    await expect(page).not.toHaveURL(/login|registration-status/);
    await expectNoDocumentHorizontalOverflow(page);

    const employeeRow = manager.locator("tr, article.employee-card, article.application-card, article.roster-card").filter({ hasText: phone }).filter({ has: manager.getByRole("button", { name: "重置密码", exact: true }) });
    try {
      await employeeRow.getByRole("button", { name: "重置密码", exact: true }).click();
    } catch (error) {
      const candidates = manager.locator("tr, article.employee-card, article.application-card, article.roster-card").filter({ hasText: phone });
      const controls = await candidates.getByRole("button", { name: "重置密码", exact: true })
        .evaluateAll((buttons) => buttons.slice(0, 4).map((button) => ({
          visible: button.getClientRects().length > 0 && getComputedStyle(button).visibility !== "hidden",
          enabled: !button.matches(":disabled") && button.getAttribute("aria-disabled") !== "true",
        }))).catch(() => null);
      const rows = await candidates.count().then((n) => Math.min(n, 5)).catch(() => null);
      console.log("ONBOARDING_RESET_OBS " + JSON.stringify({
        project: testInfo.project.name === "mobile" ? "mobile" : "desktop",
        action: "RESET_CLICK", rows, controls, responses: resetResponses,
      }));
      throw error;
    }
    const dialog = manager.locator(".t-dialog");
    await dialog.getByText("我已核对员工本人及手机号", { exact: true }).click();
    await dialog.getByPlaceholder("请输入本人当前登录密码").fill(password);
    await dialog.getByRole("button", { name: "确认重置密码", exact: true }).click();
    await expect(dialog.getByText(/已恢复受控初始密码/)).toBeVisible();
    await expect(dialog.getByText(/首次登录必须修改/)).toBeVisible();
    await expect(dialog.getByLabel("临时密码", { exact: true })).toHaveCount(0);
    await expect(dialog.getByPlaceholder("请输入本人当前登录密码")).toHaveCount(0);
    await dialog.getByRole("button", { name: "知道了", exact: true }).click();
    await expect(manager.getByLabel("临时密码", { exact: true })).toHaveCount(0);
    await expectNoDocumentHorizontalOverflow(manager);
  } finally {
    await managerContext.close().catch(() => { /* 超时清理不覆盖原始失败位置。 */ });
  }
});

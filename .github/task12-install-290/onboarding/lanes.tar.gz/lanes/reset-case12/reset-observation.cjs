'use strict';
const {stripVTControlCharacters}=require('node:util');
const routesByAction=new Map([
  ['APPROVAL_CLICK',new Set(['directory','capabilities','applications'])],
  ['RESET_CLICK',new Set(['review','directory','capabilities'])],
]);
const keys=(value,wanted)=>value&&typeof value==='object'&&
  Object.keys(value).length===wanted.length&&wanted.every(k=>Object.hasOwn(value,k));
function projectResetObservation(raw) {
  const projected=[];
  for(const [,payload] of stripVTControlCharacters(raw).matchAll(/ONBOARDING_RESET_OBS (\{[^\r\n]{1,1500}\})/gu)){
    if(projected.length>=2) break;
    let row;
    try {row=JSON.parse(payload);} catch {continue;}
    if(!keys(row,['project','action','rows','controls','responses'])||
      !['desktop','mobile'].includes(row.project)||!routesByAction.has(row.action)||
      !(row.rows===null||(Number.isInteger(row.rows)&&row.rows>=0&&row.rows<=5))||
      !(row.controls===null||(Array.isArray(row.controls)&&row.controls.length<=4&&
        row.controls.every(x=>keys(x,['visible','enabled'])&&typeof x.visible==='boolean'&&typeof x.enabled==='boolean')))||
      !Array.isArray(row.responses)||row.responses.length>12||
      !row.responses.every(x=>keys(x,['route','status'])&&routesByAction.get(row.action).has(x.route)&&
        Number.isInteger(x.status)&&x.status>=100&&x.status<=599)) continue;
    if(!projected.some(x=>x.project===row.project)) projected.push(row);
  }
  return projected;
}
module.exports={projectResetObservation};

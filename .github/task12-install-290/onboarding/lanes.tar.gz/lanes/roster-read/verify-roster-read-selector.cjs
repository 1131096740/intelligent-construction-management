'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const api='/qualification/workspace/services/api';
const file=api+'/src/database/personnel-roster-read-http-postgres.owned282.spec.ts';
const text=fs.readFileSync(file,'utf8');
const tests=[...text.matchAll(/^  it\("([^"]+)",/gmu)].map(m=>m[1]);
const exactTitle='仅有旧项目任职的人员在两处一致标待核对，读取不新增规范授权或归属';
assert.equal(tests.length,2);
assert.equal(tests.filter(title=>title===exactTitle).length,1);
const target=text.slice(text.indexOf('it("'+exactTitle+'",'));
assert.ok(target.includes('request("/organization/directory", chairman.token)'));
const listed=JSON.parse(require('node:child_process').execFileSync(process.execPath,
  [api+'/node_modules/jest/bin/jest.js','--listTests','--json','--runInBand','--runTestsByPath',file],
  {cwd:api,encoding:'utf8',timeout:40_000,env:{PATH:process.env.PATH,HOME:'/tmp',TMPDIR:'/tmp'}}));
assert.deepEqual(listed,[file]);

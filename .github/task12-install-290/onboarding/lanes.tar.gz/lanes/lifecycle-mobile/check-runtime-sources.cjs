'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {execFileSync}=require('node:child_process');
const work='/qualification/workspace/services/api';
const original=work+'/src/database/personnel-lifecycle-http-postgres.owned282.spec.ts';
const spec=fs.readFileSync(original,'utf8');
assert.ok(spec.includes('imports: [AppModule]')&&spec.includes('--project", "mobile'));
const listed=JSON.parse(execFileSync(process.execPath,[work+'/node_modules/jest/bin/jest.js','--listTests','--json','--runInBand','--runTestsByPath',original],{
 cwd:work,encoding:'utf8',timeout:40_000,env:{PATH:process.env.PATH,HOME:'/tmp',TMPDIR:'/tmp'},
}));
assert.deepEqual(listed,[original]);

--- before
+++ after
@@ -11,7 +11,7 @@
 } = require('./task16-current259-owned-resource.cjs');
 const { archiveSevenMaterial, archiveSevenAuthOnlyDiagnosticMaterial, describeCurrent259SevenPrestateCommandFailure, describeCurrent259SevenPrestateReadbackFailure } = require('./task16-current259-seven-install.cjs');
 
-const OWNER = 'jg_task01_owner';
+const OWNER = 'jiangkong';
 const {isExactCurrentArchiveProfile}=require('./task16-current259-profile.cjs');
 const STAGES = ['archive-install-before', 'archive-install-write', 'archive-install-committed'];
 const REGISTERED_STAGES = ['archive-registered-write', 'archive-registered-committed'];
@@ -681,7 +681,7 @@
  const {source,completion,serverPort}=value,{databaseIdentity:identity,ordinary,roles,commitXid,databaseAcl}=completion;
  need(!Object.hasOwn(completion,'containerId')&&completion.status==='CURRENT259_ROLES_PROVISIONED_NOT_ADMISSION'&&completion.executionAllowed===false&&completion.nativeAdmission===false);
  need(source.candidateSha===completion.sourceSha&&hex(source.candidateSha,40)&&hex(source.tree,40)&&hex(source.sourceSealSha256,64)&&isExactCurrentArchiveProfile(source.profile)&&source.profile.candidateSha===source.candidateSha&&source.profile.sealSha256===source.sourceSealSha256&&sha(JSON.stringify(source.profile.ledger))===source.profile.ledgerSha256);
- need(/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/u.test(completion.runId)&&identity.database==='jg_task01_'+completion.runId.replaceAll('-','')&&oid(identity.databaseOid)&&oid(identity.namespaceOid)&&identity.ownerOid==='10'&&xid(identity.systemIdentifier)&&xid(commitXid));
+ need(/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/u.test(completion.runId)&&['pol113','jiangkong_pol114'].includes(identity.database)&&oid(identity.databaseOid)&&oid(identity.namespaceOid)&&identity.ownerOid==='10'&&xid(identity.systemIdentifier)&&xid(commitXid));
  need(identity.actorOid==='10'&&identity.actor===OWNER&&identity.sessionActor===OWNER&&identity.tls===true&&identity.clientAddress==='127.0.0.1'&&identity.serverAddress==='127.0.0.1'&&identity.serverPort===serverPort&&Number.isInteger(serverPort)&&serverPort>1024&&serverPort<=65535&&serverPort!==5432);
  need(ordinary&&ordinary.login===true&&/^jg_fixture_app_[a-f0-9]{24}$/u.test(ordinary.name)&&oid(ordinary.oid)&&Array.isArray(roles)&&roles.length===ROLE_NAMES.length&&databaseAcl&&Array.isArray(databaseAcl.before)&&Array.isArray(databaseAcl.after)&&databaseAcl.after.length>0);
  const qualified=roles.map((role,index)=>{need(role.name===ROLE_NAMES[index]&&oid(role.oid)&&role.login===!role.name.endsWith('_owner')&&role.xmin===String(BigInt(commitXid)%4294967296n)&&role.unlimitedValidity===true);return Object.freeze({name:role.name,oid:role.oid,login:role.login,xmin:role.xmin,unlimitedValidity:true});});

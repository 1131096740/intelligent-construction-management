--- before
+++ after
@@ -333,7 +333,7 @@
 function nativeRoleScope(text,competition=false){
  need(typeof text==='string'&&Buffer.byteLength(text)<=256*1024,'NATIVE_INPUT');
  const scope=JSON.parse(text);need(keys(scope,['identity','app','ledger','competition'])&&scope.competition===competition&&
-  plain(scope.identity)&&scope.identity.ownerOid==='10'&&/^jg_task01_[a-f0-9]{32}$/u.test(scope.identity.database)&&
+  plain(scope.identity)&&scope.identity.ownerOid==='10'&&scope.identity.actor==='jiangkong'&&scope.identity.sessionActor==='jiangkong'&&['pol113','jiangkong_pol114'].includes(scope.identity.database)&&
   plain(scope.app)&&/^jg_fixture_app_[a-f0-9]{24}$/u.test(scope.app.name)&&oid(scope.app.oid)&&Array.isArray(scope.ledger),'NATIVE_INPUT');
  return scope;
 }

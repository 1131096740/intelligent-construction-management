--- before
+++ after
@@ -13,7 +13,9 @@
 const {isExactCurrentArchiveProfile}=require('./task16-current259-profile.cjs');
 const {PAYMENT262_FAULT_RUNTIME_PROFILE}=require('./task16-current262-native-fault-profile.cjs');
 const {isExactCurrentPaymentRuntimeSource,isCurrentPaymentRuntimeMode,isCurrentPaymentVoucherMode}=require('./task16-current261-competition-profile.cjs');
-const {renderCurrent259SevenPreimage,parseCurrent259SevenPreimage,describeCurrent259SevenPreimageFailure}=require('./task16-current259-seven-preimage.cjs');
+const {renderCurrent259SevenPreimage: renderHistoricalSevenPreimage,parseCurrent259SevenPreimage,describeCurrent259SevenPreimageFailure}=require('./task16-current259-seven-preimage.cjs');
+const {bindNamedSevenPreimage,bindNamedSevenDelta,bindNamedSevenFunctionProofs}=require('./task16-seven-preimage-named-owner.cjs');
+const renderCurrent259SevenPreimage = nonce => bindNamedSevenPreimage(renderHistoricalSevenPreimage(nonce));
 const {functionProofSql}=require('./task16-registered-access-check.cjs');
 const {registeredObjectWitnessSql,schema205RegistrySql,schema205RegistryValid,schema205EnforceConfigSql,SCHEMA205_DEPARSE_LOCAL}=require('./task16-registered-object-witness.cjs');
 const {schema205ScopeSql,schema205SevenDeltaSql}=require('./task16-schema205-scope.cjs');
@@ -27,7 +29,7 @@
 const VOUCHER_GUARD='public.jg_registered_payment_voucher_file_immutable()';
 const TEMP='pg_temp."jg_current259_seven_reference"';
 const RELATION='public."InterEntityRelationshipEntry"';
-const OWNER='jg_task01_owner';
+const OWNER='jiangkong';
 const config=['search_path=pg_catalog, public, pg_temp'];
 const phases=['current259-seven-before','current259-seven-install','current259-seven-committed'];
 const fragmentNames=['funding','history-revision','write-authority','canonical-proof','intercompany','canonical-adapter','voucher'];
@@ -353,13 +355,13 @@
  const priorActual=prior.pre.actual;
  const columns=priorActual.columns.map(column=>column.name==='evidenceFileId'?{...column,notNull:false}:column);
  const changedRoutines=archiveMiddle?input.material.archiveChangedRoutines:input.material.changedRoutines;
- const postBodies=functionProofSql({functionProofs:[...input.material.newRoutines,...changedRoutines]});
+ const postBodies=bindNamedSevenFunctionProofs([...input.material.newRoutines,...changedRoutines],functionProofSql);
  return `DO $current259_seven_postimage$
 DECLARE observation jsonb; item jsonb; original jsonb; compiled jsonb; actual_scope jsonb; prior_scope jsonb; delta jsonb;
 BEGIN
  SELECT value INTO STRICT observation FROM (${reference}) w(value);
  SELECT payload INTO STRICT prior_scope FROM pg_temp.jg_current259_seven_scope;
- actual_scope := ${schema205ScopeSql()}; delta := ${schema205SevenDeltaSql()};
+ actual_scope := ${schema205ScopeSql()}; delta := ${bindNamedSevenDelta(schema205SevenDeltaSql())};
  IF observation->'actual'->'relation' IS DISTINCT FROM ${json(priorActual.relation)}
    OR observation->'actual'->'columns' IS DISTINCT FROM ${json(columns)} OR observation->'actual'->'triggers' IS DISTINCT FROM ${json(priorActual.triggers)}
    OR jsonb_array_length(observation->'actual'->'checks')<>5 OR jsonb_array_length(observation->'expected'->'checks')<>5
@@ -436,7 +438,7 @@
 function applyFragments(input,prior,reference,executorOid){
  return [
   `CREATE TEMP TABLE jg_current259_seven_scope ON COMMIT DROP AS SELECT ${schema205ScopeSql()} AS payload,${current259Schema205WitnessSql()} AS witness;`,
-  'ALTER DEFAULT PRIVILEGES FOR ROLE jg_task01_owner REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;',
+  'ALTER DEFAULT PRIVILEGES FOR ROLE jiangkong REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC;',
   `DO $current259_seven_runtime$ BEGIN PERFORM pg_catalog.set_config('jg.task16_runtime_role',${quote(input.runtime.name)},true); END $current259_seven_runtime$;`,
   ...input.material.fragments,input.material.referenceEdit,checkTransition(input,prior,reference,Boolean(executorOid)),bridgeSql(input,prior,executorOid),
   installedCheckSql(input,'pg_current_xact_id()'),
@@ -649,7 +651,7 @@
  need(value&&Object.getPrototypeOf(value)===Object.prototype&&equal(Object.keys(value).sort(),['source','id','ordinary','runtime','observer','roleCommitXid','databaseAclAfter'].sort()),'NATIVE_INPUT');
  const {source,id,ordinary,runtime,observer}=value;
  need(id&&id.tls===true&&id.clientAddress==='127.0.0.1'&&id.serverAddress==='127.0.0.1'&&Number.isInteger(id.serverPort)&&id.serverPort>1024&&id.serverPort<=65535&&id.serverPort!==5432,'NATIVE_INPUT');
- need(source&&id&&ordinary&&runtime&&observer&&id.ownerOid==='10'&&oid(id.databaseOid)&&oid(id.namespaceOid)&&xid(id.systemIdentifier)&&/^jg_task01_[a-f0-9]{32}$/u.test(id.database)&&
+ need(source&&id&&ordinary&&runtime&&observer&&id.ownerOid==='10'&&oid(id.databaseOid)&&oid(id.namespaceOid)&&xid(id.systemIdentifier)&&id.actor===OWNER&&id.sessionActor===OWNER&&['pol113','jiangkong_pol114'].includes(id.database)&&
   /^jg_fixture_app_[a-f0-9]{24}$/u.test(ordinary.name)&&oid(ordinary.oid)&&ordinary.limit===0&&ordinary.password==='absent'&&
   runtime.name==='jg_task01_runtime'&&observer.name==='jg_task01_observer'&&[runtime,observer].every(r=>oid(r.oid)&&r.limit===1&&r.login===true&&r.password==='scram')&&
   new Set(['10',ordinary.oid,runtime.oid,observer.oid]).size===4,'NATIVE_INPUT');
@@ -690,7 +692,7 @@
  need(arguments.length===2&&typeof text==='string'&&Buffer.byteLength(text)<=1024*1024,'NATIVE_INPUT');const value=JSON.parse(text);
  need(equal(Object.keys(value).sort(),['source','completion','serverPort'].sort()),'NATIVE_INPUT');
  const {source,completion,serverPort}=value,id=completion.databaseIdentity;
- need(id&&id.serverPort===serverPort&&id.actorOid==='10'&&id.actor==='jg_task01_owner'&&id.sessionActor===id.actor&&Array.isArray(completion.roles)&&completion.roles.length===9,'NATIVE_INPUT');
+ need(id&&id.serverPort===serverPort&&id.actorOid==='10'&&id.actor===OWNER&&id.sessionActor===id.actor&&Array.isArray(completion.roles)&&completion.roles.length===9,'NATIVE_INPUT');
  const role=name=>{const rows=completion.roles.filter(row=>row.name===name);need(rows.length===1,'NATIVE_INPUT');return rows[0];};
  const context=nativeSevenContext(JSON.stringify({source,id,ordinary:completion.ordinary,runtime:role('jg_task01_runtime'),observer:role('jg_task01_observer'),roleCommitXid:completion.commitXid,databaseAclAfter:completion.databaseAcl.after}));
  const input={...context,material:material(context.source,true),roleCompletion:{...context.roleCompletion,roles:completion.roles}};

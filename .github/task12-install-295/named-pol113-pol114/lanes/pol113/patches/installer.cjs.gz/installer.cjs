--- before
+++ after
@@ -57,7 +57,7 @@
 const projectLegacyReviewRelease=Object.freeze({
   ...projectDraftRelease,count:287,tree:'45e36af8cf7adf495e484d8196404f970fc9541c',terminalSha256:'dd5cce3d76dc155d75ff11dc40dfec949672353f06874c1144e2cf86249392a4',ledgerSha256:'059563979fd033f0be299fb8af3f603083ac3f877abaa48ff38b1ea5791bf5f3'
 });
-const owner = 'jg_task01_owner';
+const owner = 'jiangkong';
 const outsideRelease = Object.freeze({
   readBodySha256:readSuccessorRelease.readBodySha256,
   count:289, tree:'a1be083076018686dd8afba68c44ff9c75502014', ledgerSha256:'5c5e77dc94502b706c6e52c5761f52573e27cca46efb812f9b8b22216ec52f67',
@@ -187,29 +187,32 @@
   }
   roots.set(size,dir);
  }
- const baseUrl=new URL('postgresql://jg_task01_owner@127.0.0.1:'+port+'/'+database);baseUrl.password=password;
+ const baseUrl=new URL('postgresql://'+owner+'@127.0.0.1:'+port+'/'+database);baseUrl.password=password;
  for(const [key,value]of Object.entries({schema:'public',connection_limit:'1',sslmode:'require',sslaccept:'strict',sslcert:path.join(root,'ca.crt'),connect_timeout:'5',pool_timeout:'5'}))baseUrl.searchParams.set(key,value);
  const deploy=async(size,url=baseUrl)=>{enter('MIGRATE_'+size);await command(process.execPath,[cli,'migrate','deploy','--schema',path.join(roots.get(size),'schema.prisma')],{timeoutMs:plan.limits.migrationMs,extra:{DATABASE_URL:url.toString(),PRISMA_SCHEMA_ENGINE_BINARY:engine,PRISMA_HIDE_UPDATE_MESSAGE:'1',CHECKPOINT_DISABLE:'1'}});};
- const identity=row=>{need(row.database===database&&row.ownerOid==='10'&&row.actorOid==='10'&&row.actor==='jg_task01_owner'&&row.sessionActor==='jg_task01_owner'&&row.version===160015&&row.encoding==='UTF8'&&row.replication==='origin','NATIVE_DIRECT_MIGRATION_IDENTITY');return Object.fromEntries(['database','databaseOid','namespaceOid','actorOid','ownerOid','systemIdentifier'].map(k=>[k,row[k]]));};
+ const identity=row=>{need(row.database===database&&row.ownerOid==='10'&&row.actorOid==='10'&&row.actor===owner&&row.sessionActor===owner&&row.version===160015&&row.encoding==='UTF8'&&row.replication==='origin','NATIVE_DIRECT_MIGRATION_IDENTITY');return Object.fromEntries(['database','databaseOid','namespaceOid','actorOid','ownerOid','systemIdentifier'].map(k=>[k,row[k]]));};
  const checkLedger=(row,size)=>{need(equal(row.ledger,ledger.slice(0,size)),'NATIVE_DIRECT_MIGRATION_LEDGER');};
  await deploy(203);const first=await jsonSql(controls.inspectSql());const bound=identity(first);checkLedger(first,203);
- const migrationPlan={...bound,runId:randomUUID(),nonce:randomBytes(32).toString('hex'),appName:'jg_fixture_app_'+randomBytes(12).toString('hex'),schemaName:'jg_fixture_'+randomBytes(12).toString('hex'),technicalProfile:'CURRENT259_OWNED_TECHNICAL_V1',resourceRunId:plan.runId,migrations:migrations.slice(0,205)};
+ const migrationPlan={...bound,runId:randomUUID(),nonce:randomBytes(32).toString('hex'),appName:'jg_fixture_app_'+randomBytes(12).toString('hex'),schemaName:'jg_fixture_'+randomBytes(12).toString('hex'),ciFixture:'DYNAMIC_POL113_POL115_ENTRY_V1',migrations:migrations.slice(0,205)};
  const setup=await jsonSql(controls.setupSql(migrationPlan));controls.checkSetup(setup,migrationPlan);
  const qualified=new URL(baseUrl);qualified.searchParams.set('options','-c app.contract_archive_v2_application_role_oid='+setup.appOid+' -c app.contract_archive_v2_file_caller_oids='+JSON.stringify(setup.fileCallerOids)+' -c app.local_migration_nonce='+migrationPlan.nonce);
  await deploy(205,qualified);const completed=controls.parseReadback((await sql(controls.readbackSql(migrationPlan,setup))).stdout);need(equal(identity(completed),bound),'NATIVE_DIRECT_MIGRATION_IDENTITY');checkLedger(completed,205);controls.checkCompletion(completed,migrationPlan,setup);
  await sql(controls.cleanupSql(migrationPlan,setup));const clean=await jsonSql(controls.cleanReadSql(migrationPlan,setup));need(clean.schemaAbsent===true&&clean.eventAbsent===true&&clean.appOid===setup.appOid&&clean.applicationQualified===true,'NATIVE_DIRECT_QUALIFICATION_CLEANUP');
- const materials=[];const tail=createLocalTailQualification({plan:migrationPlan,setup,migrations},{read:async(_phase,text)=>jsonSql(text),write:async(_phase,text)=>jsonSql(text),recordMaterial:row=>{need(hash(Buffer.from(row.sql))===row.afterSha256,'NATIVE_DIRECT_SQL_MATERIAL');materials.push({kind:row.kind,beforeSha256:row.beforeSha256,afterSha256:row.afterSha256});}});
+ const materials=[];const tail=createLocalTailQualification({plan:migrationPlan,setup,migrations},{read:async(_phase,text)=>jsonSql(text),write:async(_phase,text)=>jsonSql(text)});
  for(const size of [213,215,218,221]){await deploy(size);const row=await jsonSql(controls.inspectSql());need(equal(identity(row),bound),'NATIVE_DIRECT_MIGRATION_IDENTITY');checkLedger(row,size);await tail.qualify(size);}
  await deploy(ledger.length);const final=await jsonSql(controls.inspectSql());need(equal(identity(final),bound),'NATIVE_DIRECT_MIGRATION_IDENTITY');checkLedger(final,ledger.length);
  return {plan:migrationPlan,setup,materials};
 }
 
-function runCommand(file, args, {stdin, timeoutMs = 120_000, extra, allowFailure} = {}) {
+function runCommand(file, args, {stdin, timeoutMs = 120_000, extra, allowFailure, cwd} = {}) {
   const result = spawnSync(file, args, {
     input: stdin, encoding:'utf8', timeout:timeoutMs, maxBuffer:16 * 1024 * 1024,
-    cwd:process.env.JG_RUN_ROOT || '/tmp', env:{ ...baseEnv, HOME:'/tmp', ...extra },
+    cwd:cwd ?? (process.env.JG_RUN_ROOT || '/tmp'), env:{ ...baseEnv, HOME:'/tmp', ...extra },
   });
   if (result.status !== 0 && !allowFailure) {
+    const namedSevenFailure=path.basename(file)==='psql'
+      ?require('/qualification/owner-observation.cjs').projectNamedSevenFailure(result.stderr)
+      :undefined;
     if (process.argv[2] === '--tls-probe' && typeof result.stderr === 'string') {
       const diagnostic = result.stderr.replace(/postgres(?:ql)?:\/\/[^\s]+/gu,'[redacted PostgreSQL URL]');
       process.stderr.write(diagnostic);
@@ -217,6 +220,7 @@
     // Return only structured diagnostic codes. Stderr may contain private SQL or role secrets.
     throw Object.assign(new Error('INSTALLER_COMMAND_FAILED'), {
       command: path.basename(file), exit: result.status, signal: result.signal,
+      namedSevenFailure,
       ...(path.basename(file)==='psql'
         ? {psqlObservation:require('/qualification/owner-observation.cjs').projectPsql(result.stderr)}
         : {}),
@@ -238,7 +242,33 @@
   return {stdout:result.stdout, code:result.status};
 }
 
-async function installer(receipt, probeOnly, consume, release=stableRelease) {
+const installOnly290 = Symbol('install-only290');
+const named292 = Symbol('named292');
+function verifyNamed292Inputs(predecessor, intermediate, successorFile) {
+  const successor=require('./named292/successor.cjs');
+  const proof=require('./named292/tree-proof.json');
+  const base=readLedger(predecessor), through291=readLedger(intermediate);
+  need(base.length===289&&hash(JSON.stringify(base))===proof.prefix289
+    && equal(base,through291.slice(0,289))
+    && through291.length===291&&hash(JSON.stringify(through291))===proof.intermediate291
+    && equal(through291.slice(289),proof.tail.slice(0,2))
+    && hash(JSON.stringify(through291.slice(0,290)))==='97f0ae1cfaee70060c4204b7c2cb3400fa95971b0ef6fada6204b76ea06a0ed0'
+    && capture(path.join(predecessor,'schema.prisma')).sha256===capture(path.join(intermediate,'schema.prisma')).sha256,
+    'NAMED_292_EXACT_INTERMEDIATE');
+  successor.verifySql(successorFile);
+  const final=successor.expectedLedger(through291);
+  need(successor.scope.tree===proof.tree&&equal(final.slice(-3),proof.tail)
+    && hash(JSON.stringify(final))===proof.combined292,'NAMED_292_EXACT_TERMINAL');
+  return {through291,final};
+}
+async function installer(receipt, probeOnly, consume, release=stableRelease, purpose, namedDatabase) {
+  if(purpose===installOnly290) need(!probeOnly && release===outsideRelease,'INSTALL_ONLY_290_PREDECESSOR');
+  if (purpose===named292) need(!probeOnly&&release===outsideRelease&&typeof consume==='function','NAMED_292_INSTALL_MODE');
+  const exact292=purpose===named292
+    ?verifyNamed292Inputs('/qualification/product/services/api/prisma','/qualification/product291/services/api/prisma','/qualification/named292/successor.sql')
+    :undefined;
+  let consumerLedger,named292Catalog;
+
   const historical = '/qualification/source/services/api/prisma';
   const product = '/qualification/product/services/api/prisma';
   need(process.platform === 'linux' && process.getuid() !== 0 && process.version === 'v20.20.2'
@@ -269,7 +299,7 @@
   receipt.historical = {sha:stageSha, tree:stageTree, sourceSeal:seal, ledgerSha256:profile.ledgerSha256,
     sourceAdmission:{mode:sourceAdmission.mode, ...(sourceAdmission.mode === sealedMode ?
       {metadataRows:4134, verifiedFiles:318, subsetManifestSha256:subsetManifestSha} : {})}};
-  const runId = randomUUID(), database = 'jg_task01_' + runId.replaceAll('-',''), started = Math.floor(Date.now()/1000);
+  const runId = randomUUID(), database = namedDatabase, started = Math.floor(Date.now()/1000);
   const root = fs.mkdtempSync('/tmp/jg394-'), data = path.join(root,'data');
   const plan = {runId, database, historical, source:{witness:{profile}}, prismaTools:{cli, engine}, limits:{migrationMs:180000}};
   receipt.runId = runId;
@@ -323,7 +353,7 @@
 ssl_cert_file='${root}/server.crt'
 ssl_key_file='${root}/server.key'
 password_encryption='scram-sha-256'
-max_connections=16
+max_connections=100
 shared_buffers='64MB'
 max_wal_size='64MB'
 min_wal_size='32MB'
@@ -575,6 +605,112 @@
     need(equal(final,expectedFinal), 'FINAL_UPWARD_WITNESS');
     receipt.finalWitness = final;
     receipt.status = 'INSTALLED_'+release.count+'_NOT_BUSINESS_ADMISSION';
+    if (purpose===installOnly290) {
+      const successor=require('./successor.cjs');
+      enter('INSTALL_ONLY_290_FORWARD');
+      const expected=successor.expectedLedger(ledger);
+      consumerLedger=expected;
+      fs.copyFileSync('/qualification/successor.sql',successor.stage(folder));
+      await command(process.execPath,[cli,'migrate','deploy','--schema',path.join(folder,'schema.prisma')],
+        {timeoutMs:180000,extra:{DATABASE_URL:endpoint.toString(),PRISMA_SCHEMA_ENGINE_BINARY:engine,
+        PRISMA_HIDE_UPDATE_MESSAGE:'1',CHECKPOINT_DISABLE:'1'}});
+      const installed=await jsonSql(control.inspectSql());
+      need(equal(installed.ledger,expected)&&['database','databaseOid','namespaceOid','systemIdentifier','ownerOid','actorOid','sessionActor']
+        .every(key=>installed[key]===roleIdentity[key]),'INSTALL_ONLY_290_LEDGER_IDENTITY');
+      need(equal(await jsonSql(finalSql),final),'INSTALL_ONLY_290_PROTECTED_289_CONTINUITY');
+      assertOutsideWitness(289,await jsonSql(outsideWitnessSql(289)));
+      const shape=await jsonSql(successor.catalogSql);
+      need(successor.exactCatalog(shape),'INSTALL_ONLY_290_CATALOG');
+      receipt.installOnly290={ledgerSha256:hash(JSON.stringify(installed.ledger)),count:installed.ledger.length,exactPrior289:true,shape};
+    }
+    if(exact292){
+    const originalOrdinary = {scopeClosed:true,privateBinding:true,privateTrigger:true,triggerIdentities:true,rawOwnerOnly:true};
+    const ordinaryClosedSql = (withApproval = false) => `SELECT jsonb_build_object(
+      'scopeClosed',NOT EXISTS (SELECT FROM public.jg_company_transfer_loan_repayment_scope_v1),
+      'privateBinding',EXISTS (
+        SELECT FROM pg_class c WHERE c.oid='public.jg_company_transfer_loan_repayment_scope_v1'::regclass
+          AND c.relowner=current_user::regrole::oid
+          AND NOT EXISTS (SELECT FROM aclexplode(coalesce(c.relacl,acldefault('r',c.relowner))) a
+            WHERE a.grantee<>c.relowner)
+      ),
+      'privateTrigger',EXISTS (
+        SELECT FROM pg_proc p WHERE p.oid='public.jg_check_company_transfer_loan_repayment_insert_v1()'::regprocedure
+          AND p.proowner=current_user::regrole::oid AND p.prosecdef
+          AND encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='5840396ff6f1fa7c30f3c39eb2417aab82acd988e203c4894e4118af1834de2f'
+          AND NOT EXISTS (SELECT FROM aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a
+            WHERE a.grantee<>p.proowner)
+      ),
+      'triggerIdentities',(SELECT count(*)=3 FROM pg_trigger t
+        WHERE t.tgrelid='public."CompanyTransfer"'::regclass AND t.tgenabled='O'
+          AND NOT t.tgisinternal AND t.tgnargs=0 AND (
+          (t.tgname='CompanyTransfer_original_capacity' AND t.tgtype=19 AND t.tgqual IS ${withApproval ? 'NOT ' : ''}NULL
+            AND t.tgfoid='public.guard_company_transfer_original_reservation()'::regprocedure)
+          OR (t.tgname='CompanyTransfer_original_capacity_insert_legacy' AND t.tgtype=7 AND t.tgqual IS NOT NULL
+            AND t.tgfoid='public.guard_company_transfer_original_reservation()'::regprocedure)
+          OR (t.tgname='CompanyTransfer_original_capacity_insert_loan' AND t.tgtype=7 AND t.tgqual IS NOT NULL
+            AND t.tgfoid='public.jg_check_company_transfer_loan_repayment_insert_v1()'::regprocedure)
+        )),
+      'rawOwnerOnly',(SELECT count(*)=4 AND bool_and(p.proowner=current_user::regrole::oid AND NOT p.prosecdef
+        AND NOT EXISTS (SELECT FROM aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a
+          WHERE a.grantee<>p.proowner)) FROM pg_proc p WHERE p.oid IN (
+        'public.jg_company_transfer_original_source(public."CompanyTransfer")'::regprocedure,
+        'public.jg_company_transfer_correction_delta(text,timestamp,boolean,text)'::regprocedure,
+        'public.jg_company_transfer_original_used(text,timestamp,text)'::regprocedure,
+        'public.jg_company_transfer_original_checkpoints(text,timestamp)'::regprocedure))
+      ${withApproval ? `, 'boundedApproval', EXISTS (
+        SELECT FROM pg_trigger t JOIN pg_proc p ON p.oid=t.tgfoid
+        WHERE t.tgrelid='public."CompanyTransfer"'::regclass AND t.tgenabled='O'
+          AND NOT t.tgisinternal AND t.tgnargs=0 AND t.tgtype=19 AND t.tgqual IS NOT NULL
+          AND t.tgname='CompanyTransfer_original_capacity_update_loan'
+          AND p.oid='public.jg_check_company_transfer_loan_repayment_approval_v1()'::regprocedure
+          AND p.proowner=current_user::regrole::oid AND p.prosecdef
+          AND encode(sha256(convert_to(p.prosrc,'UTF8')),'hex')='506570362fdedab705561592137d94298b2614e6dbca92dbe934d96df641e01b'
+          AND NOT EXISTS (SELECT FROM aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) a
+            WHERE a.grantee<>p.proowner)
+      )` : ''}
+      );`;
+      const successor=require('./named292/successor.cjs');
+      const identityKeys=['database','databaseOid','namespaceOid','systemIdentifier','ownerOid','actorOid','sessionActor'];
+      const verifyLedger=async expected=>{
+        const installed=await jsonSql(control.inspectSql());
+        need(equal(installed.ledger,expected)&&identityKeys.every(key=>installed[key]===roleIdentity[key]),'NAMED_292_LEDGER_IDENTITY');
+        need(equal(await jsonSql(finalSql),final),'NAMED_292_B7_CONTINUITY');
+        const outside=await jsonSql(outsideWitnessSql(289));
+        assertOutsideWitness(289,outside);
+        receipt.orderedTails.push({size:installed.ledger.length,ledgerSha256:hash(JSON.stringify(installed.ledger))});
+        return outside;
+      };
+      const deploy=async()=>command(process.execPath,[cli,'migrate','deploy','--schema',path.join(folder,'schema.prisma')],
+        {timeoutMs:180000,extra:{DATABASE_URL:endpoint.toString(),PRISMA_SCHEMA_ENGINE_BINARY:engine,
+          PRISMA_HIDE_UPDATE_MESSAGE:'1',CHECKPOINT_DISABLE:'1'}});
+      receipt.ordinaryApprovalWitnesses=[];
+      for(const size of [290,291]){
+        enter('NAMED_COMPOSED_MIGRATE_'+size);
+        native.stageCombined279Prefix(folder,exact292.through291,size,size-1,schema.bytes,row=>
+          capture(path.join('/qualification/product291/services/api/prisma/migrations',row.name,'migration.sql')));
+        await deploy();
+        const outside=await verifyLedger(exact292.through291.slice(0,size));
+        const ordinary=await jsonSql(ordinaryClosedSql(size===291));
+        need(equal(ordinary,size===291?{...originalOrdinary,boundedApproval:true}:originalOrdinary),'NAMED_292_ORDINARY_CATALOG');
+        receipt.ordinaryApprovalWitnesses.push({count:size,outside,ordinary});
+      }
+      enter('NAMED_INSTALL_292_BALANCE_CORRECTION');
+      fs.copyFileSync('/qualification/named292/successor.sql',successor.stage(folder));
+      await deploy();
+      const outside=await verifyLedger(exact292.final);
+      const ordinary=await jsonSql(ordinaryClosedSql(true));
+      need(equal(ordinary,receipt.ordinaryApprovalWitnesses.at(-1).ordinary),'NAMED_292_ORDINARY_CONTINUITY');
+      const balance=await jsonSql(successor.catalogSql);
+      need(successor.exactCatalog(balance),'NAMED_292_BALANCE_CATALOG');
+      receipt.installOnly292={count:exact292.final.length,ledgerSha256:hash(JSON.stringify(exact292.final)),
+        sameIdentity:true,exactB7:true,outside,ordinary,balance};
+      consumerLedger=exact292.final;
+      named292Catalog=async()=>({
+        outside:await jsonSql(outsideWitnessSql(289)),
+        ordinary:await jsonSql(ordinaryClosedSql(true)),
+        balance:await jsonSql(successor.catalogSql),
+      });
+    }
     if (consume) {
       let active = true;
       const onlyWhileOwned = () => {
@@ -588,7 +724,7 @@
       };
       const context = Object.freeze({
         ...(release.count === 280 ? {candidate:release.sha} :
-          {candidateTree:release.tree,sourceBaseSha:stableRelease.sha}),
+          {candidateTree:exact292?require('./named292/scope.json').tree:release.tree,sourceBaseSha:stableRelease.sha}),
         runId, database, workDir:root,
         ownerUrl:connection(owner, credentials.owner),
         runtimeUrl:connection('jg_task01_runtime', credentials.runtime),
@@ -596,7 +732,7 @@
         sql:statement => { onlyWhileOwned(); return sql(statement); },
         readPostgresLog:() => { onlyWhileOwned(); return fs.readFileSync(logPath, 'utf8'); },
       });
-      enter('EXACT_'+release.count+'_CONSUMER');
+      enter(exact292?'EXACT_292_NAMED_FRESH_CONSUMER':consumerLedger?'EXACT_290_FRESH_CONSUMER':'EXACT_'+release.count+'_CONSUMER');
       for (const [key,role] of [['runtime','jg_task01_runtime'], ['observer','jg_task01_observer']]) {
         const observed = await jsonSql(`SELECT jsonb_build_object(
           'database',current_database(),'role',current_user,'sessionRole',session_user,
@@ -615,8 +751,19 @@
         active = false;
       }
       const afterConsumer = await jsonSql(control.inspectSql());
-      need(equal(afterConsumer.ledger,ledger) && ['database','databaseOid','namespaceOid','systemIdentifier','ownerOid','actorOid','sessionActor'].every(key => afterConsumer[key] === roleIdentity[key]), 'CONSUMER_DATABASE_CONTINUITY');
+      need(equal(afterConsumer.ledger,consumerLedger ?? ledger) && ['database','databaseOid','namespaceOid','systemIdentifier','ownerOid','actorOid','sessionActor'].every(key => afterConsumer[key] === roleIdentity[key]), 'CONSUMER_DATABASE_CONTINUITY');
       need(equal(await jsonSql(finalSql), final), 'CONSUMER_PROTECTED_CATALOG_CONTINUITY');
+      if (named292Catalog) {
+        const {outside,ordinary,balance}=await named292Catalog();
+        assertOutsideWitness(289,outside);
+        need(equal(ordinary,receipt.installOnly292.ordinary)&&equal(balance,receipt.installOnly292.balance)
+          &&require('./named292/successor.cjs').exactCatalog(balance),'NAMED_292_POST_CONSUMER_CATALOG');
+        receipt.postBehavior292={catalogPreserved:true,keyUnprovisioned:true};
+      } else if (consumerLedger) {
+        const successor=require('./successor.cjs');
+        assertOutsideWitness(289,await jsonSql(outsideWitnessSql(289)));
+        need(successor.exactCatalog(await jsonSql(successor.catalogSql)),'SETTLEMENT_290_CATALOG_CONTINUITY');
+      }
       receipt.business = 'CALLBACK_COMPLETED';
     }
   } finally {
@@ -633,7 +780,7 @@
 async function installHistory(plan,root,port,credentials,sql,jsonSql,command,enter,fromHistory,stageTree,receipt){
 const {runId}=plan;
 const migration=await migrateNativeTask16(plan,root,port,credentials.owner,sql,jsonSql,command,enter,fromHistory);
-enter('ROLES');const roles=fromHistory('./task16-current259-role-provision.cjs');
+enter('ROLES');const roles=require(path.join(__dirname,'named-source/services/api/prisma/task16-current259-role-provision.cjs'));
   const roleIdentity=await jsonSql(`SELECT jsonb_build_object('database',current_database(),'databaseOid',d.oid::text,'namespaceOid',to_regnamespace('public')::oid::text,'ownerOid',d.datdba::text,'actorOid',current_user::regrole::oid::text,'actor',current_user,'sessionActor',session_user,'systemIdentifier',(SELECT system_identifier::text FROM pg_control_system()),'tls',(SELECT ssl FROM pg_stat_ssl WHERE pid=pg_backend_pid()),'clientAddress',host(inet_client_addr()),'serverAddress',host(inet_server_addr()),'serverPort',inet_server_port()) FROM pg_database d WHERE d.datname=current_database();`);
   need(roleIdentity.ownerOid==='10'&&roleIdentity.actorOid==='10'&&roleIdentity.tls===true&&roleIdentity.clientAddress==='127.0.0.1'&&roleIdentity.serverAddress==='127.0.0.1'&&roleIdentity.serverPort===port,'NATIVE_DIRECT_OWNER');
   const roleScope=JSON.stringify({identity:roleIdentity,app:{name:migration.plan.appName,oid:migration.setup.appOid,nonce:migration.plan.nonce},ledger:plan.source.witness.profile.ledger,competition:false});
@@ -644,7 +791,7 @@
   const provisioned={status:'CURRENT259_ROLES_PROVISIONED_NOT_ADMISSION',executionAllowed:false,nativeAdmission:false,sourceSha:stageSha,runId,databaseIdentity:roleIdentity,ordinary:roleRow.state.app,roles:roleRow.state.roles,commitXid:stagedRow.writeXid,databaseAcl:{before:JSON.parse(before).state.databases,after:roleRow.state.databases}};
  const run=async(label,statement)=>{enter(label);return (await sql(statement)).stdout;};
  const source={candidateSha:stageSha,sourceSealSha256:plan.source.witness.profile.sealSha256,profile:plan.source.witness.profile,tree:stageTree};
- const archive=fromHistory('./task16-current259-archive-install.cjs').beginNativeTask12ArchiveProtocol(JSON.stringify({source,completion:provisioned,serverPort:port}));
+ const archive=require(path.join(__dirname,'named-source/services/api/prisma/task16-current259-archive-install.cjs')).beginNativeTask12ArchiveProtocol(JSON.stringify({source,completion:provisioned,serverPort:port}));
  const seven=archive.acceptBefore(await run('ARCHIVE_BEFORE',archive.beforeSql));
  const archiveWriter=seven.acceptBefore(await run('ARCHIVE_SEVEN_BEFORE',seven.beforeSql));
  const archiveReader=archiveWriter.acceptWritten(await run('ARCHIVE_SEVEN_WRITE',archiveWriter.sql));
@@ -905,3 +1052,41 @@
 module.exports.assertOutsideWitness = assertOutsideWitness;
 
 module.exports.finalWitnessMismatch = finalWitnessMismatch;
+
+module.exports.withNamedPol113Pol114 = (receipt, mode, consume) => {
+  const names={pol113:'pol113',pol114:'jiangkong_pol114'};
+  need(Object.hasOwn(names,mode)&&receipt.purpose==='NAMED_POL113_POL114_EXACT_290'&&
+    typeof consume==='function','POL113_POL114_NAMED_PURPOSE');
+  const {contract289,verifyMaterialized}=require('./checkout.cjs');
+  const {scope,verifySql}=require('./successor.cjs');
+  verifyMaterialized('/qualification/product',contract289);
+  verifySql('/qualification/successor.sql');
+  const namedDatabase=names[mode];
+  Object.assign(receipt,{releaseTree:scope.tree,predecessorTree:outsideRelease.tree,
+    sourceBaseSha:stableRelease.sha,sourceKind:'UNCOMMITTED_EXACT_GIT_TREE'});
+  return installer(receipt,false,async context=>{
+    need(context.database===namedDatabase&&receipt.archive?.roles===9&&receipt.installOnly290?.count===290&&
+      receipt.installOnly290.ledgerSha256===scope.expectedLedgerSha256,'POL113_POL114_NAMED_CONTEXT');
+    await consume(context);
+  },outsideRelease,installOnly290,namedDatabase);
+};
+
+
+module.exports.verifyNamed292Inputs=verifyNamed292Inputs;
+module.exports.withNamedPol113Pol114292 = (receipt, mode, consume) => {
+  const names={pol113:'pol113',pol114:'jiangkong_pol114'};
+  need(Object.hasOwn(names,mode)&&receipt.purpose==='NAMED_POL113_POL114_EXACT_292'&&
+    typeof consume==='function','POL113_POL114_NAMED_292_PURPOSE');
+  const {contract289,verifyMaterialized}=require('./checkout.cjs');
+  const {scope}=require('./named292/successor.cjs');
+  verifyMaterialized('/qualification/product',contract289);
+  const namedDatabase=names[mode];
+  Object.assign(receipt,{releaseTree:scope.tree,predecessorTree:outsideRelease.tree,
+    sourceBaseSha:stableRelease.sha,sourceKind:'UNCOMMITTED_EXACT_GIT_TREE'});
+  return installer(receipt,false,async context=>{
+    need(context.database===namedDatabase&&context.candidateTree===scope.tree&&receipt.archive?.roles===9&&
+      receipt.installOnly292?.count===292&&receipt.installOnly292.ledgerSha256===scope.expectedLedgerSha256,
+      'POL113_POL114_NAMED_292_CONTEXT');
+    await consume(context);
+  },outsideRelease,named292,namedDatabase);
+};

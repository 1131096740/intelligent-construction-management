--- before
+++ after
@@ -9,7 +9,7 @@
 }
 export default defineConfig({
   testDir: "./e2e", testMatch: ["pol113-project-profile-real.e2e.ts", "pol113-settings-real.e2e.ts", "pol113-business-party-real.e2e.ts", "pol113-company-entity-real.e2e.ts"],
-  timeout: 45_000, workers: 1, retries: 0, reporter: "line",
+  timeout: 45_000, workers: 1, retries: 0, reporter: [["line"], ["json", { outputFile: join(tmpdir(), "pol113-" + randomUUID() + ".json") }]],
   outputDir: join(tmpdir(), `pol113-project-browser-${randomUUID()}`),
   use: { baseURL: "http://127.0.0.1:4214", trace: "retain-on-failure" },
   webServer: {

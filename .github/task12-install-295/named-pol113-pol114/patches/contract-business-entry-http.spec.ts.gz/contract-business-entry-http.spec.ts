--- before
+++ after
@@ -67,7 +67,7 @@
         "--config", "playwright.settlement-entry-history-real.config.ts",
         "--global-timeout=85000"
       ], {
-        cwd: join(__dirname, "../../../.."),
+        cwd: process.env.JG_NAMED_BROWSER_WORKSPACE_ROOT ?? join(__dirname, "../../../.."),
         env: {
           ...childEnv,
           POL114_REAL_SETTLEMENT_ID: settlementId,

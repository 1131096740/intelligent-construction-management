--- before
+++ after
@@ -443,7 +443,7 @@
           browserEnv.POL113_PARTICIPANT_PROJECTS = JSON.stringify(participantProjects);
           browserEnv.POL113_CONSTRUCTION_PROJECTS = JSON.stringify(constructionProjects);
           const child = spawn("pnpm", ["exec", "playwright", "test", "--config", "playwright.pol113-project-real.config.ts"], {
-            cwd: resolve(__dirname, "../../../../apps/web-admin"),
+            cwd: process.env.JG_NAMED_BROWSER_WEB_ROOT ?? resolve(__dirname, "../../../../apps/web-admin"),
             env: browserEnv,
             stdio: "inherit"
           });

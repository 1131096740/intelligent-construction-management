--- before
+++ after
@@ -220,7 +220,7 @@
     await new Promise<void>((resolve, reject) => {
       const env = { ...process.env }; delete env.JEST_WORKER_ID;
       const child = spawn(process.env.PNPM_BIN ?? "pnpm", ["--filter", "@jiangkong/web-admin", "exec", "playwright", "test",
-        "--config", "playwright.layout-preview-real.config.ts", "--global-timeout=120000"], { cwd: join(__dirname, "../../../.."), env: {
+        "--config", "playwright.layout-preview-real.config.ts", "--global-timeout=120000"], { cwd: process.env.JG_NAMED_BROWSER_WORKSPACE_ROOT ?? join(__dirname, "../../../.."), env: {
         ...env, LAYOUT_PREVIEW_API_URL: baseUrl, LAYOUT_PREVIEW_PHONE: staff.phone, LAYOUT_PREVIEW_PASSWORD: password,
         LAYOUT_PREVIEW_FIXTURES: JSON.stringify(browserFixtures)
       }, stdio: "inherit" });

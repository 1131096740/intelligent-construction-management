--- before
+++ after
@@ -1,3 +1,6 @@
+import { randomUUID } from "node:crypto";
+import { tmpdir } from "node:os";
+import { join } from "node:path";
 import { defineConfig, devices } from "@playwright/test";
 
 const pnpmCommand = JSON.stringify(process.env.PNPM_BIN ?? "pnpm");
@@ -8,7 +11,7 @@
   timeout: 30_000,
   expect: { timeout: 15_000 },
   workers: 1,
-  reporter: "list",
+  reporter: [["list"], ["json", { outputFile: join(tmpdir(), "pol114-settlement-" + randomUUID() + ".json") }]],
   use: {
     baseURL: "http://127.0.0.1:5173",
     trace: "retain-on-failure"

--- before
+++ after
@@ -6,7 +6,7 @@
 if (!/^http:\/\/127\.0\.0\.1:\d+$/.test(api)) throw new Error("版式浏览器验收仅允许本机隔离 API");
 export default defineConfig({
   testDir: "./e2e", testMatch: "layout-preview-real.e2e.ts", timeout: 60_000,
-  expect: { timeout: 10_000 }, workers: 1, retries: 0, reporter: "line",
+  expect: { timeout: 10_000 }, workers: 1, retries: 0, reporter: [["line"], ["json", { outputFile: join(tmpdir(), "pol114-layout-" + randomUUID() + ".json") }]],
   outputDir: join(tmpdir(), `layout-preview-browser-${randomUUID()}`),
   use: { baseURL: "http://127.0.0.1:4219", trace: "retain-on-failure" },
   webServer: { command: "pnpm dev --host 127.0.0.1 --port 4219 --strictPort",
